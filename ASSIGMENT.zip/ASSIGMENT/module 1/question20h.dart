// Write a program to find out the max from given number (E.g. No: -1562 Max number is 6 )

import 'dart:math';

void main() {}
