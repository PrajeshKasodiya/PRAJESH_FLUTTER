// Write a program to print the number in reverse order.

void main() {
  print("\n");
  for (int i = 10; i >= 1; i--) {
    print("$i");
  }
}
