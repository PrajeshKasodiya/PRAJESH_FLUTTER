import 'dart:io';

/* q-2 write a programme to make addition , substraction, multification, division , of two number    
*/

void main() {
  int num1 = 10;
  int num2 = 5;

  int ans = num1 + num2;
  int ans2 = num1 - num2;
  int ans3 = num1 * num2;
  int ans4 = num1 % num2;

  print("answer is : $ans");
  print("answer is : $ans2");
  print("answer is : $ans3");
  print("answer is : $ans4");
}
