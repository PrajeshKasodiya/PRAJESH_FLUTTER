// Write a program you have to make a summation of first and last Digit. (E.g. 1234 ans:-5)

void main() {}
