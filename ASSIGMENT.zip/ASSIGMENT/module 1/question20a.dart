// q-20 a) Write a program to print the 1 to 10 using For loop.
void main() {
  for (int i = 1; i <= 10; i++) {
    print("$i");
  }
}
