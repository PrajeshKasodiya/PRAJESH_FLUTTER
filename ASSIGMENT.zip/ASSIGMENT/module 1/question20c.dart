//q-20 c) write a program to print the 100 to 81 using do....while loop.
void main() {
  var i = 100;
  do {
    print('$i');
    i--;
  } while (i >= 80);
  {}
}
