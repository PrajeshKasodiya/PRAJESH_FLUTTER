import 'dart:io';

/* q-1  Display this information using print 
 a. your name 
 b. your birth date 
 c. your age 
 d. your address
*/

void main() {
  print("name : my name is prajesh ");
  print("birth date : 17/07/2002");
  print("age : 20 ");
  print("address : soladi , ta- dhangadhara , dist - surendranagar");
}
